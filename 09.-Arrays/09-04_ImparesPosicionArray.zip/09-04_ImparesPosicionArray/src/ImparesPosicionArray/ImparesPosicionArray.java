/*
Escribe un programa que dibuje por pantalla los valores impares de un array de enteros (tipo int) y su posición
en el array. Por ejemplo, si para el indice 1 tenemos el valor 5, el programa debería escribir:
"El valor 5 es impar y ocupa la posición 2 en el array".(recuerda que el indice de un array comienza en 0)
El array se proporciona hardcodeado en el método main, pero el programa tiene que funcionar para cualquier
longitud del array (si añadimos o eliminamos elementos del array el programa tiene que seguir funcionando)
 */
package ImparesPosicionArray;

public class ImparesPosicionArray {

        public static void main(String[] args) {
        
        int numeros[]={3,5,2,10,7};
        
        int numElementos = numeros.length;
              
        for (int i=0;i<numElementos;i++){
            if (numeros[i]%2!=0){
                System.out.println("El valor "+numeros[i]+" es impar y ocupa la posición "+(i+1)+" en el array");
            }
        }  

    }
    
}
