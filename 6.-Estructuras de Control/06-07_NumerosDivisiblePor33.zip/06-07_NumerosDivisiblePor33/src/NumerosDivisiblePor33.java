public class NumerosDivisiblePor33 {

    public static void main(String[] args) {
        int contador=0;
        for (int i=1;i<=1000;i++){
            if (i%33==0){
                System.out.println("el numero "+i+" es divisible por 33");
                contador++;
            }
        }
        System.out.println("total de numeros divisibles por 33: "+contador);
    }
    
}
