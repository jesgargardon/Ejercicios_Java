package ManejandoUCIs;
/*
Crea una clase llamada Habitacion que tenga los siguientes parámetros:
•	numeroHabitación (tipo integer y privado): indicará el número de habitación.
•	numeroPlanta (tipo integer y privado): indicará en que planta del hospital está la habitación.
•	libre (tipo Boolean y privado): indicará si la habitación está libre y puede por tanto ser ocupada.
La clase Habitacion tendrá un constructor que acepte todos los parámetros.

Por otro lado, crearemos la clase UCI que hereda de la clase Habitacion, que será la superclase.
La clase UCI tendrá las siguientes características:
•	Tiene dos parámetros adicionales:
1.	sanitario (tipo String): Nombre del sanitario al cargo de la UCI.
2.	paciente: Paciente que ocupa la UCI.
•	Tiene que tener un constructor que acepte todos los parámetros, incluidos los que hereda de la superclase.
•	Tiene que tener un método llamado dibujarDatos que dibuja por pantalla todos los datos de un objeto UCI.

Y en nuestra clase con el método main, programaremos las siguientes acciones:
•	Tienes que crear un array de 5 objetos UCI.
•	Inicializa los 5 elementos del array a un valor. Esta parte puede estar hardcodeada.
•	Una vez inicializadas las UCI, muestra por pantalla el estado de todas ellas.
•	Después debes pedir al usuario que introduzca por teclado el nombre de un nuevo paciente.
•	Si hay al menos una UCI libre, tienes que colocar al paciente en dicha UCI y mostrar por pantalla el estado actualizado de las UCIs, y el programa termina su ejecución.
•	Si todas las UCIs estuvieran ocupadas, tienes que indicarlo, decir que no tienes una UCI libre donde colocar al nuevo paciente y finalizar el programa.

 */
public class Habitacion {
    private int numeroHabitacion;
    private int numeroPlanta;
    private boolean libre;

    public Habitacion(int numeroHabitacion, int numeroPlanta, boolean libre) {
        this.numeroHabitacion = numeroHabitacion;
        this.numeroPlanta = numeroPlanta;
        this.libre = libre;
    }

    public int getNumeroHabitacion() {
        return numeroHabitacion;
    }

    public void setNumeroHabitacion(int numeroHabitacion) {
        this.numeroHabitacion = numeroHabitacion;
    }

    public int getNumeroPlanta() {
        return numeroPlanta;
    }

    public void setNumeroPlanta(int numeroPlanta) {
        this.numeroPlanta = numeroPlanta;
    }

    public boolean isLibre() {
        return libre;
    }

    public void setLibre(boolean libre) {
        this.libre = libre;
    }
    
    
}
