package test.ejercicio1;

/*
Crea un programa que pinte por pantalla los números impares del array numeros declarado e inicializado en el método main
El programa tiene que funcionar si cambiaramos los valores del array o añadieramos o quitaramos valores
*/
public class TestEjercicio1Solucionado {
    
    public static void main(String[] args) {
        int numeros[] ={3,4,7,8,23,12,45,7};
        for (int i=0;i<numeros.length;i++){
            if (numeros[i]%2!=0){
            System.out.print(numeros[i]+" , ");
            }
        }
    }
    
}
