/*
7_5.-ArrayClasePersonaEstudiante
--------------------------------
- Crea una Clase Persona que tenga como parametros el nombre y el año de nacimiento. Además tendra un método
que calcule la edad de la Persona mediante la resta del año actual y el año de nacimiento. El año actual se
pasa como parámetro al método.
- Crea una Clase Estudiante que herede de Persona y que tenga un parámetro que indique la carrera que estudia el estudiante.
Además, tendrá un método que dibuje por pantalla todos los datos del Estudiante, también los heredados.
- En el programa principal, pide al usuario que introduzca los datos de tres estudiantes. Crea un array de estudiantes y
almacena los tres estudiantes introducidos por el usuario en el array. Finalmente, pinta por pantalla los datos de los tres estudiantes.
 */

package ClasePersonaEstudianteArray;

import java.util.Scanner;

public class ClasePersonaEstudianteArray {

    public static void main(String[] args) {
        Estudiante estudiantes[] = new Estudiante[3];
        Scanner sc1 = new Scanner (System.in);
        String nombre;
        Scanner sc2 = new Scanner (System.in);
        int añoNac;
        Scanner sc3 = new Scanner (System.in);
        String carrera;
        
        for (int i=0;i<3;i++){
            System.out.println("Por favor, introduce el nombre del estudiante: "+(i+1));
            nombre=sc1.nextLine();
            System.out.println("Introduce el año de nacimiento del estudiante: "+(i+1));
            añoNac=sc2.nextInt();
            System.out.println("Que carrera estudia el estudiante: "+(i+1));
            carrera=sc3.nextLine();
            estudiantes[i]= new Estudiante(carrera,nombre,añoNac);
        }
        for (int i=0;i<3;i++){
            System.out.println("-------------Datos del estudiante nº "+(i+1)+"------------");
            estudiantes[i].dibujarDatos();
            System.out.println("El estudiante tiene "+estudiantes[i].edad(2020)+" años");
        }
        sc1.close();sc2.close();sc3.close();
    }
}
