/*
7-1_MediaValoresArray
Escribe un programa que dibuje por pantalla la media de los valores de un array de enteros (tipo int)
El array se proporciona hardcodeado en el método main, pero el programa tiene que funcionar para cualquier
longitud del array (si añadimos o eliminamos elementos del array el programa tiene que seguir funcionando)
El resultado no puede ser aproximado a entero, sino que tendrá decimales si no es entero
 */
package MediaValoresArray;

public class MediaValoresArray {

    public static void main(String[] args) {
        
        int numeros[]={3,5,2,10,7};
        
        float media;
        int numElementos = numeros.length;
        int suma = 0;
        
        for (int i=0;i<numElementos;i++){
            suma = suma + numeros[i];
        }  
        media = (float)suma /(float)numElementos;
        System.out.println("La media es: "+media);
    }
    
}
