/*
4-1_AcertarNumero
Realiza un programa en el que el usuario tendrá que acertar un número entre 1 y 1000.
Dicho número está hardcodeado en la variable valor.
El usuario tiene que introducir un número entre 1 y 1000 por teclado. No es necesario comprobar
que el usuario introduce el número correctamente.
El número de intentos para acertar es ilimitado, y el programa seguirá pidiéndole al usuario que
introduzca un número hasta que este acierte. Sólo en esa situación el programa termina.
Tras cada introducción, el programa tiene que indicar los intentos que lleva el usuario y si el número introducido
es mayor o menor que el valor que hay que acertar.
Cuando se acierte, se presenta un texto diciendo que se ha acertado y el número de intentos que se han necesitado.
 */
package AcertarNumero;

import java.util.Scanner;

public class AcertarNumero {


    public static void main(String[] args) {
        int intentos = 0;
        int valor=500;
        int introducido;
        boolean acertado = false;
        Scanner sc = new Scanner (System.in);
        System.out.println("Tienes que acertar un número entre 1 y 1000");
        do{
            System.out.println("Introduce un numero: ");
            introducido = sc.nextInt();
            if (introducido == valor){
                acertado = true;
                System.out.println("Enhorabuena, has acertado el número. Te ha llevado "+ intentos +" intentos.");
            }
            else if (introducido<valor){
                intentos++;
                System.out.println("El numero introducido es menor que el que tienes que acertar");
                System.out.println("Llevas "+intentos+" intentos. Sigue probando");
            }else{
                intentos++;
                System.out.println("El numero introducido es mayor que el que tienes que acertar");
                System.out.println("Llevas "+intentos+" intentos. Sigue probando");
            }
        }while(!acertado);
    }
    
}
