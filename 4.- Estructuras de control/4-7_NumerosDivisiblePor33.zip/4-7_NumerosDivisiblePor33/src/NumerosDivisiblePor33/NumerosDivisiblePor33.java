/*Empleando un bucle for, dibuja por pantalla todos los numeros
 * entre el 1 y el 1000 que son disivibles por 33.
 * Tras mostrar los números divisible por 33, indicar tambien por
 * pantalla cuantos números son.
 */
package NumerosDivisiblePor33;

public class NumerosDivisiblePor33 {

    public static void main(String[] args) {
        int contador=0;
        for (int i=1;i<=1000;i++){
            if (i%33==0){
                System.out.println("el numero "+i+" es divisible por 33");
                contador++;
            }
        }
        System.out.println("total de numeros divisibles por 33: "+contador);
    }
    
}
