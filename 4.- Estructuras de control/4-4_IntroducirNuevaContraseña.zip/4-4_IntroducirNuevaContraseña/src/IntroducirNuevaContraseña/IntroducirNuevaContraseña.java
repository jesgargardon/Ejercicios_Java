/*
Codificar un programa Java que solicita al usuario la introducción de una nueva contraseña.
Para ser segura, la contraseña debe tener más de 7 caracteres. 
Si la longitud de la nueva contraseña es inferior a ocho, debe solicitar de nuevo al usuario
que introduzca una nueva contraseña con más de siete caracteres. (Nótese que 7 caracteres no es suficiente).
Una vez introducida la nueva contraseña, se pide al usuario que la introduzca de nuevo.
A continuación, el programa comprueba si la contraseña introducida es la misma que
la nueva contraseña introducida la primera vez por el usuario. 
Si ambos son iguales, imprima un mensaje en la pantalla que diga: "Su contraseña se ha cambiado con exito". 
Si ambos son diferentes se vuelve a pedir al usuario que introduzca de nuevo la segunda contraseña. 
El usuario tiene 3 intentos para introducir la contraseña igual a la nueva contraseña introducida al principio. 
Si el usuario falla todos los intentos, debe imprimir un mensaje en la pantalla que diga: 
"Lo sentimos, ha superado el número de intentos para cambiar la contraseña. Inténtelo de nuevo después de 5 minutos"
y finaliza el programa.
 */
package IntroducirNuevaContraseña;
import java.util.Scanner;
public class IntroducirNuevaContraseña {

    public static void main(String[] args) {
        Scanner sc1= new Scanner(System.in);

        String nuevaContraseña;
        boolean contraseñaSegura = false;
        do{
            System.out.println("Por favor, introduce una nueva contraseña");
            System.out.println("La contraseña debe tener mas de 7 caracteres");
            nuevaContraseña= sc1.nextLine();
            if (nuevaContraseña.length()>7){
                contraseñaSegura = true;
            }
        }while(!contraseñaSegura);
        
        String segundaContraseña;
        boolean igual= false;
        int intentos = 0;
        do{
            System.out.println("Por favor, introduzca de nuevo la nueva contraseña");
            segundaContraseña= sc1.nextLine();intentos++;
            if (segundaContraseña.equals(nuevaContraseña)){
                igual = true;
                System.out.println("Su contraseña se ha cambiado con éxito");
            }else {
                System.out.println ("La segunda contraseña introducida es diferente a la primera");
            }
        }while(!igual && intentos<3);
        if (intentos==3){
            System.out.println("Lo sentimos, ha superado el número de intentos para cambiar la contraseña. Inténtelo de nuevo después de 5 minutos");
        }
    }
}
