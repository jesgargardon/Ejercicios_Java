/*
Codifica un programa que pida al usuario que introduzca un número entre 1 y 1000, 
e imprima todos los divisores exactos de ese número.
Por ejemplo, si el número introducido por el usuario fuera 170, el resultado debería ser algo similar a:
Por favor, introduce un numero entre 1 y 1000
170
El numero 170 es divisible por 1
El numero 170 es divisible por 2
El numero 170 es divisible por 5
El numero 170 es divisible por 10
El numero 170 es divisible por 17
El numero 170 es divisible por 34
El numero 170 es divisible por 85
El numero 170 es divisible por 170
*/
package DivisoresExactos;
import java.util.Scanner;

public class DivisoresExactos {

    public static void main(String[] args) {
        
        Scanner sc1= new Scanner(System.in);
        System.out.println("Por favor, introduce un numero entre 1 y 1000");
        int num = sc1.nextInt();
        for (int i=1; i<1001;i++){
            if (num%i==0){
                System.out.println("El numero "+num+" es divisible por "+i);
            }
        }
    }
}
